<?php
$locale_arr = array (
"language" => "Chinese (simplified)",
"template" => array (
        "T_CHOOSE_LANGUAGE" => "选择语言",
        "T_GO" => "去",
        "T_LOGGED_IN_AS" => "登录为",
        "T_LOGIN" => "登录",
        "T_LOGOFF" => "注销",
        "T_ADMIN_HOME" => "管理主页",
        "T_CONFIG_PROJECT" => "配置项目",
        "T_CREATE_REPORT" => "创建报告",
        "T_ENTER_PROJECT_PASSWORD" => "输入项目密码",
        "T_ENTER_PROJECT_PASSWORD_DEMO" => "输入项目密码。这些教程的密码是 <b>reportico</b>",
        "T_UNABLE_TO_CONTINUE" => "",
		"T_PASSWORD_ERROR" => "不正确的密码。再试一次。",
),
);
?>

