<?php
$locale_arr = array (
        "language" => "English",
        "template" => array (
            "T_CHOOSE_LANGUAGE" => "Elegir el idioma",
            "T_LOGGED_IN_AS" => "Iniciado la sesión como",
		    "T_LOGIN" => "Acceder",
            "T_GO" => "Ejecutar",
		    "T_LOGOFF" => "Salir",
		    "T_ADMIN_HOME" => "Menú de Administración",
            "T_CONFIG_PROJECT" => "Configurar Proyecto",
            "T_CREATE_REPORT" => "Crear Informe",
            "T_ENTER_PROJECT_PASSWORD" => "Introduzca la contraseña del proyecto",
            "T_ENTER_PROJECT_PASSWORD_DEMO" => "Introduzca la contraseña del proyecto.<br>La contraseña de estos tutoriales es <b>reportico</b>",
            "T_UNABLE_TO_CONTINUE" => "Incapaz de Seguir",
		    "T_PASSWORD_ERROR" => "Contraseña incorrecta. Inténtelo de nuevo.",
            ),
        );
?>

