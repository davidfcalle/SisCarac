<?php
$locale_arr = array (
        "language" => "Spanish",
        "template" => array (
            "T_en_gb" => "Inglés (UK)",
            "T_en_us" => "Inglés (US)",
            "T_fr_fr" => "Francés",
            "T_it_it" => "Italiano",
            "T_ar_ar" => "Árabe",
            "T_zh_cn" => "Chino (Simplificado)",
            "T_es_es" => "Español",
            ),
        );
?>
